﻿/// <reference path="userCreationView.html" />
	'use strict';
    var app = angular.module("AlphaProTracker");
	app.controller('userCreationController', ['$scope',  function ($scope) {

    //init Method
 //   function init() {
//        $scope.ValueSave = "Save";
//        $scope.isdelete = true;
//        $scope.isupdate = false;
//    }
//    //call init method
//    init();
//
//    //fetch 
//    userCreationService.getUserCreationData($scope.userCreation).success(function (data) {
//        $scope.RoleUserCreations = data.RoleUserCreations;
//        $scope.UserCreations = data.UserCreations;
//    }).error(function (data) {
//        $scope.error = "An Error has occured while loading posts! " + data.ExceptionMessage;
//        console.log($scope.error);
//    })
//
//    //save and update
//    $scope.save = function (userCreation) {
//        if ($scope.ValueSave == 'Save') {
//            userCreationService.insertUserCreationData(userCreation).success(function (data) {
//                $scope.UserCreations = data;
//                alert("Saved Successfully");
//            }).error(function (data) {
//                $scope.error = "An Error has occured while loading posts! " + data.ExceptionMessage;
//                console.log($scope.error);
//            })
//        }
//        else {
//            userCreationService.updateUserCreationData(userCreation).success(function (data) {
//                $scope.UserCreations = data;
//
//                alert("Updated Successfully");
//            }).error(function (data) {
//                $scope.error = "An Error has occured while loading posts! " + data.ExceptionMessage;
//                console.log($scope.error);
//            })
//        }
//        $scope.clear();
//    };
//
//    //Delete
//    $scope.Delete = function (userCreation) {
//        userCreationService.deleteUserCreationData(userCreation).success(function (data) {
//            $scope.UserCreations = data;
//            alert("Deleted Successfully");
//        }).error(function (data) {
//            $scope.error = "An Error has occured while loading posts! " + data.ExceptionMessage;
//            console.log($scope.error);
//        })
//    };

    //Sorting
    $scope.sort = function (keyname) {
        $scope.sortBy = keyname;   //set the sortBy to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }

    //Edit to fetch the grid
    $scope.edit = function (UserCreation) {
        $scope.ValueSave = "Update";
        $scope.issave = false;
        $scope.isdelete = false;
        $scope.userCreation = UserCreation;
        $scope.userCreation.licenseUpto = new Date(UserCreation.licenseUpto);
        
    };
  

    //clear inputs
    $scope.clear = function () {
        $scope.userCreation = {};
        $scope.userCreation.licenseUpto = null;
        init();
    };



  

}]);