﻿$(document).ready(function ($timeout) {
    $('.quicksearch').focus(function () {
        $('.close-btn').addClass('open');
    });
    
    $timeout(function (){
        var $container = $('.grid');
        var qsRegex = '';
        $container.isotope({
            filter: function () {
                var str = $(this).attr('data-href');
                /*$(this).removeAttr('data-href');
                alert(str);*/
                var cat = true;
                if ($('.secondary-tab .select').length > 0) {
                    cat = $(this).is($('.secondary-tab .select').data('filter'));
                }
                var sbox = qsRegex ? str.match(new RegExp(qsRegex, 'ig')) : true;
                return sbox && cat ? true : false;
            },
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            }
        });
        $(document).on('click', ".secondary-tab a", function () {
            $('.secondary-tab .select').removeClass('select');
            $(this).addClass('select');
            var selector = $(this).attr('data-filter');
            $quicksearch.val('');
            qsRegex = '';
            $container.isotope();
            return false;
        });
		$(document).on('click', ".close-btn.open", function () {
			$(this).removeClass('open');
			$quicksearch.val('');
            qsRegex = '';
            $container.isotope();
            return false;
		});
        var $quicksearch = $('.quicksearch').keyup(debounce(function () {
            qsRegex = $quicksearch.val();
            $container.isotope();

        }, 200));
        function debounce(fn, threshold) {
            var timeout;
            return function debounced() {
                if (timeout) {
                    clearTimeout(timeout);
                }
                function delayed() {
                    fn();
                    timeout = null;
                }
                timeout = setTimeout(delayed, threshold || 100);
            }
        }

		});


});