(function () {
	'use strict';
    var app = angular.module("ODMSApplication", ['ngRoute','ngAnimate','ngMaterial', 'ngMessages','ngMaterialDatePicker','md-steppers','igTruncate']);
	app.config(['$routeProvider', function($routerProvider) {
		$routerProvider
		.when("/", {
			templateUrl : "/login.html"
		})
		.when("/dashboard", {
			templateUrl : "/dashboard.html"
		})
		.when("/player-registration", {
			templateUrl : "/player-registration.html"
		})
		.when("/district-master", {
			templateUrl : "/district-master.html"
		})
		.when("/ground-master", {
			templateUrl : "/ground-master.html"
		})
		.when("/player-category", {
			templateUrl : "/player-category.html"
		})
		.when("/team-master", {
			templateUrl : "/team-master.html"
		})
		.when("/tournament-master", {
			templateUrl : "/tournament-master.html"
		})
		.when("/places-master", {
			templateUrl : "/places-master.html"
		})
		.when("/scoring-master", {
			templateUrl : "/scoring-master.html"
		})
		.when("/officials-category-master", {
			templateUrl : "/officials-category-master.html"
		})
		.when("/create-tournament", {
			templateUrl : "/create-tournament.html"
		})
		.when("/elite-promotion", {
			templateUrl : "/elite-promotion.html"
		})
		.when("/player-transfer", {
			templateUrl : "/player-transfer.html"
		})
		.when("/player-transfer-approval", {
			templateUrl : "/player-transfer-approval.html"
		})
		.when("/player-registration", {
			templateUrl : "/player-registration.html"
		})
		.when("/player-registration", {
			templateUrl : "/player-registration.html"
		})
		.when("/player-registration", {
			templateUrl : "/player-registration.html"
		})
	}]);
	app.controller('RegistrationCtrl', function($scope, $mdDialog) {
  $scope.status = '  ';
  $scope.customFullscreen = false;

  $scope.showAdvanced = function(ev) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'player-registration-details.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true,
      fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
    })
    .then(function(answer) {
      $scope.status = 'You said the information was "' + answer + '".';
    }, function() {
      $scope.status = 'You cancelled the dialog.';
    });
  };

  function DialogController($scope, $mdDialog) {
    $scope.hide = function() {
      $mdDialog.hide();
    };

    $scope.cancel = function() {
      $mdDialog.cancel();
    };

    $scope.answer = function(answer) {
      $mdDialog.hide(answer);
    };
  }
});

}());