(function () {
	'use strict';
    var app = angular.module("ODMSApplication");
	app.directive("sidebarCtrl", ["$timeout", "$location", function($timeout, $location){
		return{
			link: link,
			restrict:'A'
		};
		function link()
		{
			var ourLocation = $location.path();
			//alert(ourLocation);
			$('.nav li a').each(function () {
				if ($(this).attr('href') === ("#"+ourLocation)) {
					$(this).parents('li').addClass('active');
					$(this).closest('li').parent('.submenu').show();
					$(this).toggleClass('select');
				}
			});
			$(document).on('click', ".nav li a", function () {
				//alert('hi');
				$('.nav li a').removeClass('select');
				$('.nav li').removeClass('active open');
				$('.nav li .submenu').removeClass('nav-show').addClass('nav-hide').hide();
				$(this).parents('li').addClass('active open');
				$('.nav li.active.open > .submenu').addClass('nav-show').removeClass('nav-hide').show();
				$(this).parent().removeClass('open').addClass('active');
				$(this).toggleClass('select');
				var pageURL = $(this).attr('href');
				if (pageURL !== "javascript:void(0);")
				{
					$('.apps-left').animate({marginLeft:-220});
					$('.toggle-btn.expanded').removeClass('expanded').addClass('collapsed').animate({marginLeft:5});
				}
			});
			$timeout(function (){
				var bdyHeight = $('body').height();
				var logoHeight = $('.logo').height();
				var menuHeight = bdyHeight - logoHeight;
				var hdrHeight = $('header').outerHeight();
				$('.sidebar').attr('style', 'height:' + menuHeight + 'px;');
			});
			$(document).on('click', ".toggle-btn.collapsed", function () {
				$('.apps-left').animate({marginLeft:0});
				$(this).removeClass('collapsed').addClass('expanded').animate({marginLeft:225});
			});
			$(document).on('click', ".toggle-btn.expanded, .toggle-dashboard", function () {
				$('.apps-left').animate({marginLeft:-220});
				$('.toggle-btn.expanded').removeClass('expanded').addClass('collapsed').animate({marginLeft:5});
			});
		}
	}]);
	
	app.directive("innerpageHeight", ["$window", "$timeout", function(window, $timeout) {
		return {
			link: link,
			restrict: 'A'
		 };
		function link(scope){
			$timeout(function (){
				var bdyHeight = $(window).height();
				var hdrHeight = $('.header-right').outerHeight(true);
				var logoHeight = $('.logo').outerHeight(true);
				var titleHeight = $('.page-title').outerHeight(true);
				var inputHeight = $('.input-container').outerHeight(true);
				var leftinputHeight = $('.left-container .input-container').outerHeight(true);
				var rightinputHeight = $('.right-container .input-container').outerHeight(true);
				var outputHeight = $('.output-container').outerHeight(true);
				var leftoutputHeight = $('.left-container .output-container').outerHeight(true);
				var rightoutputHeight = $('.right-container .output-container').outerHeight(true);
				var searchHeight = $('.search-container').outerHeight(true);
				var tblHdrHeight = $('.scrollable-table .table thead').outerHeight(true);
				
				var scrollcontainer1 = bdyHeight - hdrHeight - titleHeight - inputHeight - 30;
				var scrollcontainer2 = bdyHeight - hdrHeight - titleHeight - 20;
				var scrollcontainer3 = scrollcontainer1 - searchHeight - tblHdrHeight - 20;
				var scrollcontainer4 = scrollcontainer2 - searchHeight - tblHdrHeight - 20;
				var scrollcontainer5 = scrollcontainer2 - leftinputHeight - 10;
				var scrollcontainer6 = scrollcontainer5 - inputHeight - 10;
				
				$('.output-container > .white, .left-container.yes-input > .white, .right-container.yes-input > .white').attr('style', 'height:' + scrollcontainer1 + 'px; position:relative;overflow:visible;');
				$('.left-container.no-input > .white,.right-container.no-input > .white').attr('style', 'height:' + scrollcontainer2 + 'px; position:relative;overflow:visible;');
				$('.scrollable-table .table tbody').attr('style', 'height:' + scrollcontainer3 + 'px; position:relative;overflow:visible;');
				$('.right-container.no-input > .white .scrollable-table .table tbody').attr('style', 'height:' + scrollcontainer4 + 'px; position:relative;overflow:visible;');
				$('.left-container.no-input .output-container > .white').attr('style', 'height:' + scrollcontainer5 + 'px; position:relative;overflow:visible;');
				$('.left-container.yes-input .output-container > .white').attr('style', 'height:' + scrollcontainer6 + 'px; position:relative;overflow:visible;');
			
				$('.video-container').mouseover (function () {
					$('.button-controls').animate({ bottom: 0}, 200);
				});
				$('.video-container').mouseleave (function () {
					$('.button-controls').animate({ bottom: -42}, 200);
				});
			});
			$(window).bind('resize', function(){
				link(scope);
         		//scope.$digest();
       		});
			progressAnimation();
			customScroll();
		}
		function customScroll(){
			$timeout(function (){
				$("scroll-xy, .scrollable-table").mCustomScrollbar({
					axis:"yx",
					scrollButtons:{enable:true},
					advanced:{autoScrollOnFocus:false},
					theme:"minimal",
					scrollbarPosition:"outside"
				});
				$(".scroll-y, .scrollable-table tbody").mCustomScrollbar({
					axis:"y",
					scrollButtons:{enable:true},
					advanced:{autoScrollOnFocus:false},
					theme:"minimal",
					scrollbarPosition:"outside"
				});
				$(".scroll-x").mCustomScrollbar({
					axis:"x",
					scrollButtons:{enable:true},
					advanced:{autoExpandHorizontalScroll:true},
					theme:"minimal",
					scrollbarPosition:"outside"
				});
			});
		}
	       	
		$(document).on('click', ".main-tab a, .secondary-tab > a, .third-tab a", function () {
			var parentRelID = $(this).parent().attr('rel');
			var parentClassName = $(this).parent().attr('class');
			var relID = $(this).attr('rel');
			//alert(parentRelID);
			$('.' + parentRelID + ' .' + parentClassName + '-container').hide();
			$(this).parent().find('a').removeClass('select');
			$(this).addClass('select');
			$('.' + parentRelID + ' .' + parentClassName + '-container.' + relID).show();
			var maxHeight = 0;
			$(".h2h .h2h-container").each(function () {
				if ($(this).outerHeight(true) > maxHeight) { maxHeight = $(this).height(); }
			});
			$(".h2h-container").outerHeight(maxHeight);
			progressAnimation();
			customScroll();
		});
		$(document).on('click', ".show-more a", function () {
			var parentRelID = $(this).parent().attr('rel');
			$('.' + parentRelID).slideToggle();
		});
		function progressAnimation()
		{
			//alert('hi');
			$('.linear-chart').each(function() {
				$(this).find('.linear-value').animate({
				  width:$(this).attr('data-percentage')
				},2000);
				
				$(this).find('.progress-number-mark').animate(
				  {left:$(this).attr('data-percentage')},
				  {
				   duration: 2000,
				   step: function(now, fx) {
					 var data = Math.round(now);
					 $(this).find('.percent').html(data + '%');
				   }
				});
			});
		}
	}]);
	app.directive("alertNotification", ["$document", function(document){
		return{
			link: link,
			restrict:'A'
		};
		function link()
		{
			$(document).on('click', ".alert-notification", function () {
				$('.alert-popup').hide();
				$(this).parent().find('.alert-popup').toggle();
				return false;
			});
			$(document).click(function (event) {
				var msglist = $('.alert-notification');
				if (!$(event.target).is('.alert-popup')) {
					if (msglist.is(":visible")) {
						$('.alert-popup').fadeOut();
					}
				}
			});
		}
	}]);

	app.directive('chooseFile', function() {
		return {
			link: function (scope, elem, attrs) {
			var button = elem.find('button');
			var input = angular.element(elem[0].querySelector('input.fileInput'));
			button.bind('click', function() {
				input[0].click();
			});
			input.bind('change', function(e) {
				scope.$apply(function() {
					var files = e.target.files;
					if (files[0]) {
						scope.fileName = files[0].name;
					} else {
						scope.fileName = null;
					}
				});
			});
		  }
		};
	});
	app.directive("toggleAccordion", ["$timeout", function($timeout){
		return{
			link: link,
			restrict:'A'
		};
		function link()
		{
			$timeout(function (){
				$(document).on('click', ".accordtion", function () {
					$('.accordion-container').slideToggle();
					if ($('.accordtion a').text() == "Show More")
						$('.accordtion a').text("Show Less")
					else
						$('.accordtion a').text("Show More");
				});
			});
		}
	}]);
}());