(function () {
	'use strict';
    var app = angular.module("ODMSApplication", ['ngRoute','ngAnimate','ngMaterial', 'ngMessages','ngMaterialDatePicker','md-steppers']);
	app.config(['$routeProvider', function($routerProvider) {
		$routerProvider
		.when("/", {
			templateUrl : "/login.html"
		})
		.when("/dashboard", {
			templateUrl : "/dashboard.html"
		})
		.when("/player-registration", {
			templateUrl : "/player-registration.html"
		})
		.when("/district-master", {
			templateUrl : "/district-master.html"
		})
		.when("/ground-master", {
			templateUrl : "/ground-master.html"
		})
		.when("/player-category", {
			templateUrl : "/player-category.html"
		})
		.when("/team-master", {
			templateUrl : "/team-master.html"
		})
		.when("/tournament-master", {
			templateUrl : "/tournament-master.html"
		})
		.when("/places-master", {
			templateUrl : "/places-master.html"
		})
		.when("/scoring-master", {
			templateUrl : "/scoring-master.html"
		})
		.when("/officials-category-master", {
			templateUrl : "/officials-category-master.html"
		})
		.when("/create-tournament", {
			templateUrl : "/create-tournament.html"
		})
		.when("/elite-promotion", {
			templateUrl : "/elite-promotion.html"
		})
		.when("/player-transfer", {
			templateUrl : "/player-transfer.html"
		})
		.when("/player-transfer-approval", {
			templateUrl : "/player-transfer-approval.html"
		})
		.when("/tournament-stats", {
			templateUrl : "/tournament-stats.html"
		})
		.when("/tournament-stats-details", {
			templateUrl : "/tournament-stats-details.html"
		})
		.when("/tournament-stats-batting", {
			templateUrl : "/tournament-stats-batting.html"
		})
		.when("/tournament-stats-bowling", {
			templateUrl : "/tournament-stats-bowling.html"
		})
		.when("/cscs-dashboard", {
			templateUrl : "/cscs-dashboard.html"
		})
		.when("/district-dashboard", {
			templateUrl : "/district-dashboard.html"
		})
		.when("/player-stats", {
			templateUrl : "/player-stats.html"
		})
		.when("/view-fixtures", {
			templateUrl : "/view-fixtures.html"
		})
		.when("/results", {
			templateUrl : "/results.html"
		})
		.when("/match-center", {
			templateUrl : "/match-center.html"
		})
		.when("/trail", {
			templateUrl : "/trail.html"
		})
		.when("/trail-selection", {
			templateUrl : "/trail-selection.html"
		})
		.when("/testReport", {
			templateUrl : "/testReport.html"
		})
		.when("/screen-config", {
			templateUrl : "/screen-config.html"
		})
		.when("/player-report", {
			templateUrl : "/player-report.html"
		})
		.when("/display-name", {
			templateUrl : "/display-name.html"
		})
	}]);
	app.controller('RegistrationCtrl', function($scope, $mdDialog) {
	  $scope.status = '  ';
	  $scope.customFullscreen = false;

	  $scope.showAdvanced = function(ev) {
		$mdDialog.show({
		  controller: DialogController,
		  templateUrl: 'player-registration-details.html',
		  parent: angular.element(document.body),
		  targetEvent: ev,
		  clickOutsideToClose:true,
		  fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
		})
		.then(function(answer) {
		  $scope.status = 'You said the information was "' + answer + '".';
		}, function() {
		  $scope.status = 'You cancelled the dialog.';
		});
	  };

	  function DialogController($scope, $mdDialog) {
		$scope.hide = function() {
		  $mdDialog.hide();
		};

		$scope.cancel = function() {
		  $mdDialog.cancel();
		};

		$scope.answer = function(answer) {
		  $mdDialog.hide(answer);
		};
	  }
	});
	app.controller('PlayerStatsAdvFltrCtrl', function($scope, $mdDialog) {
	  $scope.status = '  ';
	  $scope.customFullscreen = false;

	  $scope.showAdvanced1 = function(ev) {
		$mdDialog.show({
		  controller: DialogController,
		  templateUrl: 'player-stats-adv-fltr.html',
		  parent: angular.element(document.body),
		  targetEvent: ev,
		  clickOutsideToClose:true,
		  fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
		})
		.then(function(answer) {
		  $scope.status = 'You said the information was "' + answer + '".';
		}, function() {
		  $scope.status = 'You cancelled the dialog.';
		});
	  };

	  function DialogController($scope, $mdDialog) {
		$scope.hide = function() {
		  $mdDialog.hide();
		};

		$scope.cancel = function() {
		  $mdDialog.cancel();
		};

		$scope.answer = function(answer) {
		  $mdDialog.hide(answer);
		};
	  }
	});
	app.controller('SelectHeaderController', function($scope, $element) {
		  $scope.vegetables = ['Corn' ,'Onions' ,'Kale' ,'Arugula' ,'Peas', 'Zucchini'];
		  $scope.searchTerm;
		  $scope.clearSearchTerm = function() {
			$scope.searchTerm = '';
		  };
		  // The md-select directive eats keydown events for some quick select
		  // logic. Since we have a search input here, we don't need that logic.
		  $element.find('input').on('keydown', function(ev) {
			  ev.stopPropagation();
		  });
    });
	app.controller('claimCtrl', function($scope, $mdDialog) {
	  $scope.status = '  ';
	  $scope.customFullscreen = false;

	  $scope.showAdvanced = function(ev) {
		$mdDialog.show({
		  controller: DialogController,
		  templateUrl: 'official-claim.html',
		  parent: angular.element(document.body),
		  targetEvent: ev,
		  clickOutsideToClose:true,
		  fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
		})
		.then(function(answer) {
		  $scope.status = 'You said the information was "' + answer + '".';
		}, function() {
		  $scope.status = 'You cancelled the dialog.';
		});
	  };

	  function DialogController($scope, $mdDialog) {
		$scope.hide = function() {
		  $mdDialog.hide();
		};

		$scope.cancel = function() {
		  $mdDialog.cancel();
		};

		$scope.answer = function(answer) {
		  $mdDialog.hide(answer);
		};
	  }
	});

}());